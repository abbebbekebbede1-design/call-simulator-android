package com.example.callsimulator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Ink = Color(0xFF101820)
private val Muted = Color(0xFF9AA7B2)
private val Green = Color(0xFF20C779)
private val Red = Color(0xFFE94B5B)
private val SurfaceDark = Color(0xFF1B2833)

private data class Contact(val name: String, val number: String, val initials: String)

private val contacts = listOf(
    Contact("Alex Morgan", "+1 202 555 0142", "AM"),
    Contact("Taylor Reed", "+1 202 555 0188", "TR"),
    Contact("Jordan Lee", "+1 202 555 0126", "JL"),
    Contact("Sam Parker", "+1 202 555 0194", "SP"),
    Contact("Casey Brooks", "+1 202 555 0163", "CB")
)

private enum class Screen { HOME, INCOMING, ACTIVE, ENDED }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CallSimulatorApp() }
    }
}

@Composable
private fun CallSimulatorApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var selected by remember { mutableStateOf(contacts[0]) }
    var incoming by remember { mutableStateOf(false) }
    var seconds by remember { mutableIntStateOf(0) }
    var muted by remember { mutableStateOf(false) }
    var speaker by remember { mutableStateOf(false) }
    var keypad by remember { mutableStateOf(false) }
    var dialNumber by remember { mutableStateOf("") }

    LaunchedEffect(screen) {
        if (screen == Screen.ACTIVE) {
            seconds = 0
            while (true) {
                delay(1000)
                seconds++
            }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink,
            surface = SurfaceDark,
            primary = Green,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            when (screen) {
                Screen.HOME -> HomeScreen(
                    onIncoming = {
                        selected = contacts.random()
                        incoming = true
                        screen = Screen.INCOMING
                    },
                    onCall = { contact ->
                        selected = contact
                        incoming = false
                        screen = Screen.ACTIVE
                    },
                    dialNumber = dialNumber,
                    onDialChange = { dialNumber = it },
                    onDialCall = {
                        if (dialNumber.isNotBlank()) {
                            selected = Contact("Unknown number", dialNumber, "??")
                            incoming = false
                            screen = Screen.ACTIVE
                        }
                    }
                )
                Screen.INCOMING -> CallScreen(
                    contact = selected,
                    subtitle = "Incoming simulated call",
                    incoming = true,
                    seconds = 0,
                    muted = false,
                    speaker = false,
                    keypad = false,
                    onMute = {},
                    onSpeaker = {},
                    onKeypad = {},
                    onAccept = { screen = Screen.ACTIVE },
                    onEnd = { screen = Screen.ENDED }
                )
                Screen.ACTIVE -> CallScreen(
                    contact = selected,
                    subtitle = "Simulated call",
                    incoming = false,
                    seconds = seconds,
                    muted = muted,
                    speaker = speaker,
                    keypad = keypad,
                    onMute = { muted = !muted },
                    onSpeaker = { speaker = !speaker },
                    onKeypad = { keypad = !keypad },
                    onAccept = {},
                    onEnd = {
                        screen = Screen.ENDED
                        muted = false; speaker = false; keypad = false
                    }
                )
                Screen.ENDED -> EndedScreen(
                    contact = selected,
                    duration = formatTime(seconds),
                    onHome = { screen = Screen.HOME }
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(
    onIncoming: () -> Unit,
    onCall: (Contact) -> Unit,
    dialNumber: String,
    onDialChange: (String) -> Unit,
    onDialCall: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(26.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.PhoneInTalk, null, tint = Green, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(10.dp))
            Text("Call Simulator", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        }
        Text("Practice calls in a safe, simulated environment", color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(28.dp))

        Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text("DIAL A NUMBER", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = dialNumber,
                    onValueChange = onDialChange,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Enter a phone number", color = Muted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green,
                        unfocusedBorderColor = Muted,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = onDialCall, enabled = dialNumber.isNotBlank(), modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Ink)) {
                    Icon(Icons.Default.Call, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Start simulated call", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(Modifier.height(18.dp))
        OutlinedButton(onClick = onIncoming, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) {
            Icon(Icons.Default.CallReceived, null, tint = Green)
            Spacer(Modifier.width(8.dp))
            Text("Simulate incoming call")
        }
        Spacer(Modifier.height(26.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("CONTACTS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("${contacts.size} available", color = Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(contacts) { contact ->
                Row(
                    Modifier.fillMaxWidth().background(SurfaceDark, RoundedCornerShape(16.dp))
                        .clickable { onCall(contact) }.padding(13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(contact.initials, 46)
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text(contact.name, fontWeight = FontWeight.SemiBold)
                        Text(contact.number, color = Muted, fontSize = 12.sp)
                    }
                    IconButton(onClick = { onCall(contact) }) {
                        Icon(Icons.Default.Call, null, tint = Green)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("All calls are simulated. No real number is dialed.", color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun CallScreen(
    contact: Contact,
    subtitle: String,
    incoming: Boolean,
    seconds: Int,
    muted: Boolean,
    speaker: Boolean,
    keypad: Boolean,
    onMute: () -> Unit,
    onSpeaker: () -> Unit,
    onKeypad: () -> Unit,
    onAccept: () -> Unit,
    onEnd: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(62.dp))
        Text(if (incoming) "INCOMING CALL" else "CALL SIMULATOR", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(38.dp))
        Avatar(contact.initials, 112)
        Spacer(Modifier.height(24.dp))
        Text(contact.name, fontSize = 29.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(contact.number, color = Muted, fontSize = 15.sp)
        Spacer(Modifier.height(12.dp))
        Text(if (incoming) subtitle else if (keypad) "Keypad open" else if (muted) "Microphone muted" else if (speaker) "Speaker on" else formatTime(seconds),
            color = if (incoming) Green else Muted, fontSize = 14.sp)
        Spacer(Modifier.weight(1f))

        if (!incoming) {
            if (keypad) {
                val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#")
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    keys.chunked(3).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                            row.forEach { key ->
                                Box(Modifier.size(58.dp).background(SurfaceDark, CircleShape), contentAlignment = Alignment.Center) {
                                    Text(key, fontSize = 22.sp)
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(18.dp))
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    CallControl(Icons.Default.MicOff, "Mute", muted, onMute)
                    CallControl(Icons.Default.Dialpad, "Keypad", false, onKeypad)
                    CallControl(Icons.Default.VolumeUp, "Speaker", speaker, onSpeaker)
                }
            }
        }

        Spacer(Modifier.height(36.dp))
        if (incoming) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                ActionButton(Icons.Default.CallEnd, "Decline", Red, onEnd)
                ActionButton(Icons.Default.Call, "Answer", Green, onAccept)
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                ActionButton(Icons.Default.CallEnd, "End call", Red, onEnd)
            }
        }
        Spacer(Modifier.height(48.dp))
    }
}

@Composable
private fun EndedScreen(contact: Contact, duration: String, onHome: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.CallEnd, null, tint = Red, modifier = Modifier.size(54.dp))
        Spacer(Modifier.height(22.dp))
        Text("Call ended", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text(contact.name, color = Muted)
        Text("Duration · $duration", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(34.dp))
        Button(onClick = onHome, colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Ink)) {
            Icon(Icons.Default.Home, null)
            Spacer(Modifier.width(8.dp))
            Text("Back to home")
        }
    }
}

@Composable
private fun Avatar(initials: String, size: Int) {
    Box(Modifier.size(size.dp).background(Color(0xFF304B5C), CircleShape), contentAlignment = Alignment.Center) {
        Text(initials, color = Color.White, fontSize = (size / 3.1).sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun CallControl(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = onClick, modifier = Modifier.size(62.dp).background(if (active) Green else SurfaceDark, CircleShape)) {
            Icon(icon, null, tint = if (active) Ink else Color.White)
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun ActionButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, color: Color, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = onClick, modifier = Modifier.size(72.dp).background(color, CircleShape)) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(label, color = Color.White, fontSize = 13.sp)
    }
}

private fun formatTime(totalSeconds: Int): String {
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%02d:%02d".format(minutes, seconds)
}
